// ============================================================
// Bedside Recovery Workshop — registration backend
// Deploy as: Extensions > Apps Script (inside your Google Sheet) > paste this file
// Then: Deploy > New deployment > Web app
//   Execute as: Me
//   Who has access: Anyone
// Copy the /exec URL into js/gas.js as CONFIG.GAS_EXEC_URL
// ============================================================

const SHEET_NAMES = {
  REGISTRATIONS: "Registrations",
  TARGET_LIST: "TargetList",
  DEPT_OVERRIDE: "DeptOverride",
};

function getSheet(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(headers);
  }
  return sh;
}

function doGet(e) {
  return ContentService.createTextOutput(
    JSON.stringify({ status: "ok", message: "Bedside Recovery backend is running" })
  ).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const action = e.parameter.action;
  let result;
  try {
    switch (action) {
      case "register":
        result = registerEmployee(ss, e.parameter);
        break;
      case "admin_add":
        result = addTarget(ss, e.parameter);
        break;
      case "admin_remove":
        result = removeTarget(ss, e.parameter);
        break;
      case "admin_set_override":
        result = setOverride(ss, e.parameter);
        break;
      default:
        result = { status: "error", message: "unknown action: " + action };
    }
  } catch (err) {
    result = { status: "error", message: String(err) };
  }
  return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(
    ContentService.MimeType.JSON
  );
}

// ---------------------------------------------------------
// Registration: one row per employee. Re-registering with a
// new RoundID overwrites their previous row (moves their round).
// ---------------------------------------------------------
function registerEmployee(ss, p) {
  const sh = getSheet(ss, SHEET_NAMES.REGISTRATIONS, [
    "Timestamp",
    "EmployeeID",
    "Name",
    "Position",
    "Dept",
    "RoundID",
  ]);
  const data = sh.getDataRange().getValues();
  const idCol = 1; // EmployeeID column index (0-based)
  let existingRow = -1;
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][idCol]) === String(p.EmployeeID)) {
      existingRow = i + 1; // 1-based sheet row
      break;
    }
  }
  const row = [new Date(), p.EmployeeID, p.Name, p.Position, p.Dept, p.RoundID];
  if (existingRow > 0) {
    sh.getRange(existingRow, 1, 1, row.length).setValues([row]);
  } else {
    sh.appendRow(row);
  }
  return { status: "ok" };
}

// ---------------------------------------------------------
// Target list management
// ---------------------------------------------------------
function addTarget(ss, p) {
  const sh = getSheet(ss, SHEET_NAMES.TARGET_LIST, ["EmployeeID", "Name", "Position", "Dept"]);
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(p.EmployeeID)) {
      return { status: "ok", message: "already exists" };
    }
  }
  sh.appendRow([p.EmployeeID, p.Name, p.Position, p.Dept]);
  return { status: "ok" };
}

function removeTarget(ss, p) {
  const sh = getSheet(ss, SHEET_NAMES.TARGET_LIST, ["EmployeeID", "Name", "Position", "Dept"]);
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(p.EmployeeID)) {
      sh.deleteRow(i + 1);
      break;
    }
  }
  // Also remove any existing registration for this employee.
  const regSh = getSheet(ss, SHEET_NAMES.REGISTRATIONS, [
    "Timestamp",
    "EmployeeID",
    "Name",
    "Position",
    "Dept",
    "RoundID",
  ]);
  const regData = regSh.getDataRange().getValues();
  for (let i = 1; i < regData.length; i++) {
    if (String(regData[i][1]) === String(p.EmployeeID)) {
      regSh.deleteRow(i + 1);
      break;
    }
  }
  return { status: "ok" };
}

// ---------------------------------------------------------
// Department target overrides
// ---------------------------------------------------------
function setOverride(ss, p) {
  const sh = getSheet(ss, SHEET_NAMES.DEPT_OVERRIDE, ["Dept", "OverrideCount"]);
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(p.Dept)) {
      sh.getRange(i + 1, 2).setValue(p.OverrideCount);
      return { status: "ok" };
    }
  }
  sh.appendRow([p.Dept, p.OverrideCount]);
  return { status: "ok" };
}

// ---------------------------------------------------------
// One-time helper: run manually from the Apps Script editor
// to pre-fill TargetList with the initial 74 employees, if you
// want the sheet (not just the embedded js/data.js) to hold them.
// Optional — the site works from js/data.js even if you skip this.
// ---------------------------------------------------------
function seedTargetListFromJSON() {
  // Paste the contents of target_employees.json here as EMPLOYEES,
  // then run this function once from the Apps Script editor.
  const EMPLOYEES = []; // <-- paste array here
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = getSheet(ss, SHEET_NAMES.TARGET_LIST, ["EmployeeID", "Name", "Position", "Dept"]);
  EMPLOYEES.forEach((e) => sh.appendRow([e.id, e.name, e.position, e.dept]));
}
