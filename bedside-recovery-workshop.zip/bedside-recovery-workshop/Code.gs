// ============================================================
// Bedside Recovery Workshop — registration backend
//
// IMPORTANT: This is the ONLY file that should exist in this
// Apps Script project. Do not add a second file with the
// contents of the website's <script> code (that code runs in
// the visitor's browser, not here) — a second file with browser
// code (fetch, document, iframe, etc.) will break this project,
// since Apps Script compiles every file together.
//
// SETUP:
// 1. Paste your Google Sheet ID below (SHEET_ID).
// 2. Deploy > New deployment > Web app
//      Execute as: Me
//      Who has access: Anyone
// 3. Copy the /exec URL into CONFIG.GAS_EXEC_URL inside
//    index.html and admin.html.
// ============================================================

const SHEET_ID = "PUT_YOUR_GOOGLE_SHEET_ID_HERE";

const SHEET_NAMES = {
  REGISTRATIONS: "Registrations",
  TARGET_LIST: "TargetList",
  DEPT_OVERRIDE: "DeptOverride",
};

function getSS() {
  return SpreadsheetApp.openById(SHEET_ID);
}

function getSheet(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.appendRow(headers);
  }
  return sh;
}

function doGet(e) {
  return ContentService.createTextOutput(
    JSON.stringify({ status: "ok", message: "Bedside Recovery backend is running" })
  ).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const ss = getSS();
  const action = e.parameter.action;
  let result;
  try {
    switch (action) {
      case "register":
        result = registerEmployee(ss, e.parameter);
        break;
      case "admin_add":
        result = addTarget(ss, e.parameter);
        break;
      case "admin_remove":
        result = removeTarget(ss, e.parameter);
        break;
      case "admin_set_override":
        result = setOverride(ss, e.parameter);
        break;
      default:
        result = { status: "error", message: "unknown action: " + action };
    }
  } catch (err) {
    result = { status: "error", message: String(err) };
  }
  return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(
    ContentService.MimeType.JSON
  );
}

// ---------------------------------------------------------
// Registration: one row per employee. Re-registering with a
// new RoundID overwrites their previous row (moves their round).
// ---------------------------------------------------------
function registerEmployee(ss, p) {
  const sh = getSheet(ss, SHEET_NAMES.REGISTRATIONS, [
    "Timestamp",
    "EmployeeID",
    "Name",
    "Position",
    "Dept",
    "RoundID",
  ]);
  const data = sh.getDataRange().getValues();
  const idCol = 1; // EmployeeID column index (0-based)
  let existingRow = -1;
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][idCol]) === String(p.EmployeeID)) {
      existingRow = i + 1; // 1-based sheet row
      break;
    }
  }
  const row = [new Date(), p.EmployeeID, p.Name, p.Position, p.Dept, p.RoundID];
  if (existingRow > 0) {
    sh.getRange(existingRow, 1, 1, row.length).setValues([row]);
  } else {
    sh.appendRow(row);
  }
  return { status: "ok" };
}

// ---------------------------------------------------------
// Target list management
// ---------------------------------------------------------
function addTarget(ss, p) {
  const sh = getSheet(ss, SHEET_NAMES.TARGET_LIST, ["EmployeeID", "Name", "Position", "Dept"]);
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(p.EmployeeID)) {
      return { status: "ok", message: "already exists" };
    }
  }
  sh.appendRow([p.EmployeeID, p.Name, p.Position, p.Dept]);
  return { status: "ok" };
}

function removeTarget(ss, p) {
  const sh = getSheet(ss, SHEET_NAMES.TARGET_LIST, ["EmployeeID", "Name", "Position", "Dept"]);
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(p.EmployeeID)) {
      sh.deleteRow(i + 1);
      break;
    }
  }
  // Also remove any existing registration for this employee.
  const regSh = getSheet(ss, SHEET_NAMES.REGISTRATIONS, [
    "Timestamp",
    "EmployeeID",
    "Name",
    "Position",
    "Dept",
    "RoundID",
  ]);
  const regData = regSh.getDataRange().getValues();
  for (let i = 1; i < regData.length; i++) {
    if (String(regData[i][1]) === String(p.EmployeeID)) {
      regSh.deleteRow(i + 1);
      break;
    }
  }
  return { status: "ok" };
}

// ---------------------------------------------------------
// Department target overrides
// ---------------------------------------------------------
function setOverride(ss, p) {
  const sh = getSheet(ss, SHEET_NAMES.DEPT_OVERRIDE, ["Dept", "OverrideCount"]);
  const data = sh.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(p.Dept)) {
      sh.getRange(i + 1, 2).setValue(p.OverrideCount);
      return { status: "ok" };
    }
  }
  sh.appendRow([p.Dept, p.OverrideCount]);
  return { status: "ok" };
}

// ---------------------------------------------------------
// One-time helper: run manually from the Apps Script editor
// to pre-fill TargetList with the initial 74 employees, if you
// want the sheet (not just the embedded data in the HTML files)
// to hold them. Optional — the site works without this too.
//
// HOW TO USE:
// 1. Open target_employees.json, copy its entire contents
//    (it already starts with [ and ends with ]).
// 2. Paste it so the line below reads:
//       const EMPLOYEES = [ ...pasted array... ];
//    Do NOT paste inside existing brackets — replace the
//    whole "[]" with your pasted array.
// 3. In the toolbar, use the function dropdown (next to the
//    Run button — it currently may say "getSheet" or similar)
//    and select "seedTargetListFromJSON" specifically.
// 4. Click Run (เรียกใช้). Approve permissions if asked.
// 5. Check the Sheet — a "TargetList" tab should now exist
//    with 74 rows.
// ---------------------------------------------------------
function seedTargetListFromJSON() {
  const EMPLOYEES = []; // <-- paste array here, replacing the []
  const ss = getSS();
  const sh = getSheet(ss, SHEET_NAMES.TARGET_LIST, ["EmployeeID", "Name", "Position", "Dept"]);
  EMPLOYEES.forEach((e) => sh.appendRow([e.id, e.name, e.position, e.dept]));
}
